package com.genymotion.api;

interface package-info
{
}
